"""
Create or delete GCP project
"""
import argparse
import logging

from googleapiclient import discovery
from oauth2client.client import GoogleCredentials

def add_roles(project, member, roles):
    """
        Assigns role to users/service accounts/groups
    """
    roles_list = roles.split(",")
    credentials = GoogleCredentials.get_application_default()
    service = discovery.build(
        'cloudresourcemanager', 'v1', credentials=credentials)
    resource = project

    #get the IAM policy for the resource
    get_iam_policy_request_body = {
    }
    request = service.projects().getIamPolicy(resource=resource, body=get_iam_policy_request_body)
    response = request.execute()
    logging.info("Existing IAM Policy: '{}'".format(response))

    bindings = response['bindings']
    #create the updated IAM policy
    set_iam_policy_request_body = {}
    set_iam_policy_request_body['policy'] = {}
    set_iam_policy_request_body['policy']['bindings'] = []
    
    for binding in bindings:
        new_binding = {}
        new_binding['members'] = []
        #check if the role is in roles_list
        if binding['role'] in roles_list:
            logging.info("Creating new binding by adding member for role '{}'".format(binding['role']))
            new_binding['role'] = binding['role']
            #add existing members to bindings
            for current_member in binding['members']:
                logging.info("Adding member '{}' to role '{}'".format(current_member, binding['role']))
                (new_binding['members']).append(current_member)
            #add new member to binding
            logging.info("Adding new member '{}' to role '{}'".format(member, binding['role']))
            (new_binding['members']).append(member)
            (set_iam_policy_request_body['policy']['bindings']).append(new_binding)
        else:
            #create binding with existing members
            logging.info("Creating new binding by adding existing members for role '{}'".format(binding['role']))
            new_binding['role'] = binding['role']
            for current_member in binding['members']:
                logging.info("Adding member '{}' to role '{}'".format(current_member, binding['role']))
                (new_binding['members']).append(current_member)
            (set_iam_policy_request_body['policy']['bindings']).append(new_binding)

    #create new binding for new role
    for role in roles_list:
        #check whether this is a new role
        if not any(item.get('role', None) == role for item in bindings):
            logging.info("{} does not exist in bindings".format(role))
            #role does not exist in bindings, create new binding for the role
            new_binding = {}
            new_binding['role'] = role
            new_binding['members'] = []
            logging.info("Adding member '{}' to role '{}'".format(member, role))
            (new_binding['members']).append(member)
            (set_iam_policy_request_body['policy']['bindings']).append(new_binding)

    logging.info("Updated Policy: {}".format(set_iam_policy_request_body))

    request = service.projects().setIamPolicy(resource=resource, body=set_iam_policy_request_body)
    response = request.execute()

def remove_roles(project, member, roles):
    """
        Removes the member from roles
    """
    roles_list = roles.split(",")
    credentials = GoogleCredentials.get_application_default()
    service = discovery.build(
        'cloudresourcemanager', 'v1', credentials=credentials)
    resource = project

    #get the IAM policy for the resource
    get_iam_policy_request_body = {
    }
    request = service.projects().getIamPolicy(resource=resource, body=get_iam_policy_request_body)
    response = request.execute()
    logging.info("Existing IAM Policy: '{}'".format(response))

    bindings = response['bindings']
    #create the updated IAM policy
    set_iam_policy_request_body = {}
    set_iam_policy_request_body['policy'] = {}
    set_iam_policy_request_body['policy']['bindings'] = []

    for binding in bindings:
        new_binding = {}
        new_binding['members'] = []
        #check if the role is in roles_list
        if binding['role'] in roles_list:
            #remove member from binding and create new binding
            logging.info("Creating new binding by removing member for role '{}'".format(binding['role']))
            new_binding['role'] = binding['role']
            for current_member in binding['members']:
                #if current_member is not member, add binding
                if current_member != member:
                    logging.info("Adding member '{}' to role '{}'".format(current_member, binding['role']))
                    (new_binding['members']).append(current_member)
            (set_iam_policy_request_body['policy']['bindings']).append(new_binding)
        else:
            #create binding with existing members
            logging.info("Creating new binding by adding existing members for role '{}'".format(binding['role']))
            new_binding['role'] = binding['role']
            for current_member in binding['members']:
                logging.info("Adding member '{}' to role '{}'".format(current_member, binding['role']))
                (new_binding['members']).append(current_member)
            (set_iam_policy_request_body['policy']['bindings']).append(new_binding)

    logging.info("Updated Policy: {}".format(set_iam_policy_request_body))
    request = service.projects().setIamPolicy(resource=resource, body=set_iam_policy_request_body)
    response = request.execute()

def run(args):
    #assign or delete roles based on action argument
    if (args.action).lower() == 'add':
        #Adding roles
        add_roles(args.project, args.member, args.roles)
    elif (args.action).lower() == 'remove':
        #Removing roles
        remove_roles(args.project, args.member, args.roles)
    else:
        logging.info("Unknown action")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("project", help = "Project ID")
    parser.add_argument("action", help = "add|remove roles")
    parser.add_argument("member", help = "Member - user/service account/group")
    parser.add_argument("roles", help = "Roles - comma separated")

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
