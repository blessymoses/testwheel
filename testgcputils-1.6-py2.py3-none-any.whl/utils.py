import httplib2
import logging
import os

from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage
from google.cloud import bigquery

SCOPES = 'https://www.googleapis.com/auth/admin.directory.user https://www.googleapis.com/auth/admin.directory.group https://www.googleapis.com/auth/admin.directory.group.member https://www.googleapis.com/auth/compute https://www.googleapis.com/auth/cloud-platform'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'GCP Admin App'

def get_credentials(args):
    """Gets valid user credentials from storage.
    This is used only when this tool is executed as command line tool

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    home_dir = os.path.expanduser('~')
    credential_dir = os.path.join(home_dir, '.credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
                                   'gcp-admin-app.json')
    store = Storage(credential_path)
    credentials = store.get()
    if not credentials or credentials.invalid:
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        flow.user_agent = APPLICATION_NAME
        credentials = tools.run_flow(flow, store, args)
        logging.info('Storing credentials to ' + credential_path)
    return credentials

def get_bq_credentials(args):
    from google_auth_oauthlib import flow
    launch_browser = False
    appflow = flow.InstalledAppFlow.from_client_secrets_file(
        CLIENT_SECRET_FILE,
        scopes=['https://www.googleapis.com/auth/bigquery'])

    if launch_browser:
        appflow.run_local_server()
    else:
        appflow.run_console()
    return appflow.credentials

def get_directory_service(credentials):
    """

    :rtype: object
    """
    logging.info("Getting Google Directory Service")
    return get_service(credentials, 'admin', 'directory_v1')

def get_compute_service(credentials):
    """

    :rtype: object
    """
    logging.info("Getting Google Compute Service")
    return get_service(credentials, 'compute', 'v1')

def get_iam_service(credentials):
    """

    :rtype: object
    """
    logging.info("Getting Google IAM Service")
    return get_service(credentials, 'iam', 'v1')

def get_service(credentials, service_name, version):
    http = httplib2.Http()
    logging.info("Authorizing http library using credentials")
    credentials.authorize(http)
    return discovery.build(service_name, version, http=http)

def get_bigquery_client(credentials):
    """

    :rtype: object
    """
    logging.info("Getting Google BigQuery Client")
    return bigquery.Client(credentials=credentials)
