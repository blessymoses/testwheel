"""
Deletes the tables from BigQuery
"""
import argparse
import logging

from google.cloud import bigquery

def delete_table(bigquery_client, dataset, table_name):
    """
       Deletes the table from the dataset
    """
    logging.info("Deleting table " + table_name + " from " + dataset + " dataset...")
    dataset_ref = bigquery_client.dataset(dataset)
    table_ref = dataset_ref.table(table_name)
    bigquery_client.delete_table(table_ref)
    logging.info('Table {}:{} deleted.'.format(dataset, table_name))

def run(args):
    bq_client = bigquery.Client(project=args.project)
    tables = (args.tables).split(",")
    for table in tables:
        dataset, table_name = table.split(".")
        delete_table(bq_client, dataset, table_name)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("project", help = "Project Identifier")
    parser.add_argument("tables", help = "Names of the tables to be deleted")

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
