"""
Create or delete GCS Bucket
"""
import os
import argparse
import logging

from google.cloud import storage

def create_gcs_bucket(storage_client, bucket_name):
    """
        Creates a new Cloud Storage bucket.
    """
    logging.info("Creating bucket '{}'".format(bucket_name))
    bucket = storage_client.create_bucket(bucket_name)
    logging.info("Bucket '{}' created".format(bucket.name))

def delete_gcs_bucket(storage_client, bucket_name):
    """
       Deletes the Cloud Storage bucket and its contents
    """
    logging.info("Deleting bucket '{}'".format(bucket_name))
    #Delete the bucket's contents
    bucket = storage_client.bucket(bucket_name)
    bucket.delete_blobs(bucket.list_blobs())
    #delete the empty bucket
    bucket.delete()
    logging.info("Bucket '{}' deleted".format(bucket.name))

def run(args):
    #create or delete gcs bucket based on action argument
    project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
    if args.project:
        project_id = args.project
    storage_client = storage.Client(project=project_id)

    # storage_client = storage.Client(project=args.project)
    if (args.action).lower() == 'create':
        #Creating gcs bucket
        create_gcs_bucket(storage_client, args.bucket_name)
    elif (args.action).lower() == 'delete':
        #Deleting gcs bucke
        delete_gcs_bucket(storage_client, args.bucket_name)
    else:
        logging.info("Unknown action")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("action", help = "create|delete gcs bucket")
    parser.add_argument("bucket_name", help = "Bucket name")
    parser.add_argument("project", help = "Project ID")

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
