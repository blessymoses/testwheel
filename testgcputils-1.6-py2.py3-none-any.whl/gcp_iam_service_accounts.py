"""
Create or delete GCP project
"""
import argparse
import logging
import os

from googleapiclient import discovery
from oauth2client.client import GoogleCredentials

def create_account(service, project, service_account):
    """
       Creates Service account in the project
    """
    resource = 'projects/'+project;
    account_name, account_id = service_account.split(":")
    logging.info("Creating service account for account name '{}' with id '{}'..."
        .format(account_name, account_id))
    request_body = {
                     "accountId": account_id,
                     "serviceAccount": {
                         "displayName": account_name,
                     }
                   }
    request = service.projects().serviceAccounts().create(name=resource, body=request_body)
    response = request.execute()
    logging.info("\nService account created with DISPLAY NAME: '{}' and EMAIL '{}'\n"
        .format(response['displayName'], response['email']))

def create_service_accounts(project, service_accounts):
    """
       Creates the service accounts in the project
    """
    service_accounts_list = service_accounts.split(",")
    credentials = GoogleCredentials.get_application_default()
    service = discovery.build(
        'iam', 'v1', credentials=credentials)
    for service_account in service_accounts_list:
        #create service account
        create_account(service, project, service_account)

def delete_account(service, project, service_account):
    """
       Deletes Service account from the project
    """
    logging.info("Deleting service account '{}' ..."
        .format(service_account))
    name = 'projects/' + project + '/serviceAccounts/' + service_account
    request = service.projects().serviceAccounts().delete(name=name)
    response = request.execute()
    logging.info("\nService account '{}' deleted from project '{}'\n".format(service_account, project))

def delete_service_accounts(project, service_accounts):
    """
       Deletes the service accounts from the project
    """
    service_accounts_list = service_accounts.split(",")
    credentials = GoogleCredentials.get_application_default()
    service = discovery.build(
        'iam', 'v1', credentials=credentials)
    resource = 'projects/'+project;
    for service_account in service_accounts_list:
        #create service account
        delete_account(service, project, service_account)

def run(args):
    project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
    if args.project:
        project_id = args.project
    #create or delete service accounts based on action argument
    if (args.action).lower() == 'create':
        #Creating service accounts
        create_service_accounts(project_id, args.service_accounts)
    elif (args.action).lower() == 'delete':
        #Deleting service accounts
        delete_service_accounts(project_id, args.service_accounts)
    else:
        logging.info("Unknown action")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("project", help = "Project ID")
    parser.add_argument("action", help = "create|delete service accounts")
    parser.add_argument("service_accounts", help = "Service account details")

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
