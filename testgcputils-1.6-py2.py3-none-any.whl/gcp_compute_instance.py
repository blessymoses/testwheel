"""
Create or delete compute instances
"""
import argparse
import time

from utils import *


def wait_for_operation(compute, project, zone, operation):
    """
       Waits for the compute instance operation to finish
    """
    print('Waiting for operation to finish...')
    while True:
        result = compute.zoneOperations().get(
            project=project,
            zone=zone,
            operation=operation).execute()

        if result['status'] == 'DONE':
            print("done.")
            if 'error' in result:
                raise Exception(result['error'])
            return result

        time.sleep(1)

def create_compute_instance(credentials, project, name, zone, machine_type,
                            image_project="ubuntu-os-cloud", image_family="ubuntu-1604-lts", disk_size=10):
    """
       Creates a Google Compute Instance
    """
    compute = get_compute_service(credentials)

    # Configure the machine
    c_machine_type = "zones/%s/machineTypes/%s" % (zone, machine_type)
    # Configuring Image (OS)
    source_disk_image = "projects/%s/global/images/family/%s" % (image_project, image_family)

    config = {
        'name': name,
        'machineType': c_machine_type,

        # Specify the boot disk and the image to use as a source.
        'disks': [
            {
                'boot': True,
                'autoDelete': True,
                'initializeParams': {
                    'sourceImage': source_disk_image,
                }
            },
            {
               "initializeParams": {
                  "diskSizeGb": disk_size,
                  "sourceImage": source_disk_image
                }
            }
        ],

    # Specify a network interface with NAT to access the public internet
        'networkInterfaces': [{
            'network': 'global/networks/default',
            'accessConfigs': [
                {'type': 'ONE_TO_ONE_NAT', 'name': 'External NAT'}
            ]
        }],
    }

    operation = compute.instances().insert(
        project=project,
        zone=zone,
        body=config).execute()
    wait_for_operation(compute, project, zone, operation['name'])
    logging.info("Compute instance '{}' created in zone '{}'".format(name, zone))


def delete_compute_instance(credentials, project, name, zone):
    """
       Deletes the Google Compute Instance
    """
    compute = get_compute_service(credentials)

    operation = compute.instances().delete(
        project=project,
        zone=zone,
        instance=name).execute()
    wait_for_operation(compute, project, zone, operation['name'])
    logging.info("Compute instance '{}' in zone '{}' deleted.".format(name, zone))


def run_create_compute_engine(args):
    """
    Run function which will be used for cli interface
    :param args:
    :return:
    """
    credentials = get_credentials(args)
    create_compute_instance(credentials, args.project, args.name, args.zone, args.machine_type,
                            args.image_project, args.image_family, args.disk_size)


def run_delete_compute_engine(args):
    """
    Run function which will be used for cli interface
    :param args:
    :return:
    """
    credentials = get_credentials(args)
    delete_compute_instance(credentials, args.project, args.name, args.zone)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(parents=[tools.argparser])
    parser.add_argument("project", help = "Project ID")

    subparsers = parser.add_subparsers(help='sub command')
    parser_create = subparsers.add_parser('create', help='Create Google Compute Engine Instance')
    parser_create.add_argument("name", help = "Name of Compute Engine instance")
    parser_create.add_argument("zone", help = "Zone in which instance has to be created")
    parser_create.add_argument("machine_type", help = "Type of instance to be created")
    parser_create.add_argument("--disk_size",
                               default = "10",
                               help = "Disk Size in GB")
    parser_create.add_argument("--image_project",
                               default = "ubuntu-os-cloud",
                               help = "Image Project. Refer https://cloud.google.com/compute/docs/images#os-compute-support")
    parser_create.add_argument("--image_family",
                               default = "ubuntu-1604-lts",
                               help = "Image Faimly. Refer https://cloud.google.com/compute/docs/images#os-compute-support")
    parser_create.set_defaults(func=run_create_compute_engine)

    parser_delete = subparsers.add_parser('delete', help='Deletes a Google Compute Engine Instance')
    parser_delete.add_argument("name", help = "Name of Compute Engine instance")
    parser_delete.add_argument("zone", help = "Zone in which instance is running")
    parser_delete.set_defaults(func=run_delete_compute_engine)

    args = parser.parse_args()
    args.func(args)
