"""
Creates External tables in BigQuery which references GCS
"""
import argparse
import logging

from google.cloud import bigquery
from google.cloud.bigquery.external_config import ExternalConfig

def create_table(bq_client, dataset, table_name, gcs_location, skip_leading_rows):
    """
    Creates the table in the given dataset.
    """
    logging.info("Creating table '{}' in dataset '{}' from '{}'".format(table_name, dataset, gcs_location))

    dataset_ref = bq_client.dataset(dataset)
    table_ref = dataset_ref.table(table_name)

    new_table = bigquery.Table(table_ref)

    src_uri = [gcs_location]
    #external data configuration
    ec = ExternalConfig('CSV')
    ec.autodetect = True
    ec.source_uris = src_uri
    ec.options.skip_leading_rows = skip_leading_rows
    new_table.external_data_configuration = ec

    bq_client.create_table(new_table)

    logging.info("Created table '{}' in dataset '{}'.".format(table_name, dataset))

def run(args):
    bq_client = bigquery.Client(project=args.project)

    create_table(bq_client, args.dataset, args.table, args.gcs_location, args.skip_leading_rows)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("project", help = "Project Identifier")
    parser.add_argument("dataset", help = "Name of the dataset")
    parser.add_argument("table", help = "Name of the table")
    parser.add_argument("gcs_location", help = "URI of the external data source in GCS")
    parser.add_argument("--skip_leading_rows", help = "Number of header rows to skip", default = 1)

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
