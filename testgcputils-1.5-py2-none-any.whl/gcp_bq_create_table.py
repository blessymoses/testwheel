"""
Reads the table schema from excel files and creates tables in BigQuery
"""
import argparse
import logging
import pandas as pd
import os

from google.cloud import bigquery

def get_file_name_list(directory):
    """
        Reads filenames from the directory
        Returns the list of file names
    """
    objects = os.listdir(directory)
    filenames = []
    for i in objects:
        if os.path.isfile(os.path.join(directory, i)):
            filenames.append(i)
    logging.info("Number of files in the directory '{}': {}".format(directory, len(filenames)))
    return filenames

def create_table(bq_client, table_schema, dataset, table_name, partitioned_table_flag):
    """
    Creates the table in the given dataset.
    """
    logging.info("Creating table '{}' in dataset '{}'".format(table_name, dataset))
    
    dataset_ref = bq_client.dataset(dataset)
    table_ref = dataset_ref.table(table_name)

    new_table = bigquery.Table(table_ref)
    new_table.schema = table_schema

    if partitioned_table_flag:
        new_table.partitioning_type = ("DAY")

    new_table = bq_client.create_table(new_table)

    logging.info("Created table '{}' in dataset '{}'.".format(table_name, dataset))

def create_tables(bq_client, input_directory):
    """
       Reads each file in the directory and creates BigQuery tables
    """
    #get the list of files in the directory
    file_names = get_file_name_list(input_directory)
    #process each file in the directory
    for file_name in file_names:
        logging.info("Reading file '{}'".format(file_name))
        xl = pd.ExcelFile(input_directory+'/'+file_name)
        sheet_names_list = xl.sheet_names
        sheet_name = sheet_names_list[0]
        #logging.info(sheet_name)
        dataset, table_name, extension = file_name.split(".")
        #parse sheet
        logging.info("Parsing '{}' ...".format(sheet_name))
        data_frame = xl.parse(sheet_name)
        #get the header row values in the sheet
        header_column_name = data_frame.columns[0] #Column field
        header_column_type = data_frame.columns[1] #column type
        header_column_mode = data_frame.columns[2] #column mode
        header_column_desc = data_frame.columns[3] #column description
        #construct the table schema
        table_schema = []
        partitioned_table_flag = False
        logging.info("Constructing the schema for '{}'".format((dataset+'.'+table_name)))
        for index, row in data_frame.iterrows():
            #check if the first row is partition time
            if row[header_column_name] == "_PARTITIONTIME":
                partitioned_table_flag = True
                #Do not construct schemafield for this row
            else:
                #construct the SchemaField and append to table_schema
                new_field = bigquery.SchemaField(row[header_column_name], row[header_column_type], mode=row[header_column_mode], description=row[header_column_desc])
                table_schema.append(new_field)
        #create the table
        create_table(bq_client, table_schema, dataset, table_name, partitioned_table_flag)
        #end of parse sheet

def run(args):
    bq_client = bigquery.Client(project=args.project)
    #read excel sheet and update descriptions
    create_tables(bq_client, args.input_directory)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("project", help = "Project Identifier")
    parser.add_argument("input_directory", help = "Name of the Directory which contains the excel files")

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
