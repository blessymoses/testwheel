"""
Create or delete BigQuery dataset
"""
import argparse
import logging
import os

from google.cloud import bigquery

def create_dataset(bigquery_client, dataset_name, project_id):
    """
       Craetes a dataset in a given project.
       If no project is specified, then the currently active project is used.
    """
    logging.info("Creating Dataset '{}' in Project '{}'".format(dataset_name, project_id))
    dataset_ref = bigquery_client.dataset(dataset_name)
    dataset = bigquery_client.create_dataset(bigquery.Dataset(dataset_ref))
    logging.info("Created dataset '{}' in Project '{}'.".format(dataset.dataset_id, project_id))

def delete_dataset(bigquery_client, dataset_name, project_id):
    """
       Deletes the bigquery dataset
    """
    logging.info("Deleting Dataset '{}' from Project '{}'".format(dataset_name, project_id))
    dataset_ref = bigquery_client.dataset(dataset_name)
    bigquery_client.delete_dataset(dataset_ref)
    logging.info("Deleted Dataset '{}' from Project '{}'.".format(dataset_name, project_id))

def run(args):
    project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
    if args.project:
        project_id = args.project
    bigquery_client = bigquery.Client(project=project_id)

    #create or delete dataset based on action argument
    if (args.action).lower() == 'create':
        #Creating dataset
        create_dataset(bigquery_client, args.dataset_name, project_id)
    elif (args.action).lower() == 'delete':
        #Deleting project
        delete_dataset(bigquery_client, args.dataset_name, project_id)
    else:
        logging.info("Unknown action")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("action", help = "create|delete dataset")
    parser.add_argument("dataset_name", help = "Dataset name, unique per project")
    parser.add_argument("project", help = "Project where the dataset belongs to")

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
