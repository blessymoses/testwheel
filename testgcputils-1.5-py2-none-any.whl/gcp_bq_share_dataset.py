"""
Assigns access control to dataset
"""
import argparse
import logging

from oauth2client import tools
from utils import *

def share_dataset(credentials, project, dataset, permission, user, entity_type = "userByEmail"):
    """
    Assigns access control to dataset
    """
    logging.info("Updating access control for the dataset '{}'...".format(dataset))

    bq_client = get_bigquery_client(credentials)
    dataset_ref = bq_client.dataset(dataset)
    #get the instance of the dataset
    dataset_info = bq_client.get_dataset(dataset_ref)
    accessctrl_entries = list(dataset_info.access_entries)

    permission = permission.upper();

    if permission == 'NONE':
        permission = None

    logging.info("Assigning '{}' permission for '{}'".format(permission, user))
    entry = bigquery.AccessEntry(
        role=permission,
        entity_type=entity_type,
        entity_id=user)
    assert entry not in dataset_info.access_entries
    accessctrl_entries.append(entry)

    dataset_info.access_entries = accessctrl_entries

    bq_client.update_dataset(dataset_info, ['access_entries'])  # API request

    logging.info("Updated access control for the dataset '{}'".format(dataset))

def run_share_dataset(args):
    """
    Run function which will be used for cli interface
    :param args:
    :return:
    """
    credentials = get_bq_credentials(args)
    share_dataset(credentials, args.project, args.dataset, args.permission, args.user, args.entity_type)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(parents=[tools.argparser])
    parser.add_argument("project", help = "Project ID")
    parser.add_argument("dataset", help = "Name of the dataset")

    subparsers = parser.add_subparsers(help='sub command')
    parser_create = subparsers.add_parser('assign', help='Assign permissions to share dataset')
    parser_create.add_argument("permission", help = "Role")
    parser_create.add_argument("user", help = "User/Group/Domain")
    parser_create.add_argument("--entity_type", 
                               default = "userByEmail", 
                               help = "Entity_Type")

    parser_create.set_defaults(func=run_share_dataset)

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    args.func(args)
