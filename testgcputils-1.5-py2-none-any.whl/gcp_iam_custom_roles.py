"""
Assigns access control to dataset
"""
import argparse
import logging

from oauth2client import tools
from utils import *

def create_customrole(credentials, project, role_id, permissions, launch_stage = "ALPHA", description=""):
    """
    Creates a custom role
    """
    logging.info("Creating role '{}'...".format(role_id))

    service = get_iam_service(credentials)

    parent = 'projects/{}'.format(project)
    launch_stage = launch_stage.upper()

    request_body = {
            "roleId": role_id,
            "role": {
                "description": description,
                "includedPermissions": [
                    permissions
                ],
                "stage": launch_stage,
            },
    }

    request = service.projects().roles().create(parent=parent, body=request_body)
    response = request.execute()

    logging.info("Created role with name '{}' and permissions {}".format(response['name'], response['includedPermissions']))

def delete_customrole(credentials, project, role_id):
    """
    Deletes a custom role
    """
    logging.info("Deleting role '{}'...".format(role_id))

    service = get_iam_service(credentials)

    role = 'projects/{PROJECT_ID}/roles/{ROLE_NAME}'.format(PROJECT_ID=project, ROLE_NAME=role_id)

    request = service.projects().roles().delete(name=role)
    response = request.execute()

    logging.info("Deleted role with name '{}'".format(response['name']))

def run_create_customrole(args):
    """
    Run function which will be used for cli interface
    :param args:
    :return:
    """
    credentials = get_credentials(args)
    logging.getLogger().setLevel(logging.INFO)
    create_customrole(credentials, args.project, args.role_id, args.permissions, args.launch_stage, args.description)

def run_delete_customrole(args):
    """
    Run function which will be used for cli interface
    :param args:
    :return:
    """
    credentials = get_credentials(args)
    logging.getLogger().setLevel(logging.INFO)
    delete_customrole(credentials, args.project, args.role_id)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(parents=[tools.argparser])
    parser.add_argument("project", help = "Project ID")

    subparsers = parser.add_subparsers(help='sub command')
    parser_create = subparsers.add_parser('create', help='Creates a custom role')
    parser_create.add_argument("role_id", help = "The role id to use for this role")
    parser_create.add_argument("permissions", help = "The names of the permissions this role grants when bound in an IAM policy")
    parser_create.add_argument("--launch_stage", 
                               default = "ALPHA", 
                               help = "The current launch stage of the role.")
    parser_create.add_argument("--description", 
                               default = "", 
                               help = "A human-readable description for the role")

    parser_delete = subparsers.add_parser('delete', help='Deletes a custom role')
    parser_delete.add_argument("role_id", help = "The role id")

    parser_create.set_defaults(func=run_create_customrole)
    parser_delete.set_defaults(func=run_delete_customrole)

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    args.func(args)
