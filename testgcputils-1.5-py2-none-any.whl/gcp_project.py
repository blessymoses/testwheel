"""
Create or delete GCP project
"""
import argparse
import logging

from googleapiclient import discovery
from oauth2client.client import GoogleCredentials

def create_project(project_id, project_name):
    """
        Creates the GCP project
    """
    logging.info('Creating Project with project ID: {}, project name: {}'.format(project_id, project_name))
    credentials = GoogleCredentials.get_application_default()
    crm = discovery.build(
        'cloudresourcemanager', 'v1', credentials=credentials)

    operation = crm.projects().create(
    body={
        'project_id': project_id,
        'name': project_name
    }).execute()
    logging.info('Created Project with project ID: {}, project name: {}'.format(project_id, project_name))

def delete_project(project_id):
    """
       Deletes the GCP project
    """
    logging.info('Deleting Project with project ID: {}'.format(project_id))
    credentials = GoogleCredentials.get_application_default()
    crm = discovery.build(
        'cloudresourcemanager', 'v1', credentials=credentials)

    project = crm.projects().delete(projectId=project_id).execute()
    logging.info('Deleted Project with project ID: {}'.format(project_id))

def run(args):
    #create or delete project based on action argument
    if (args.action).lower() == 'create':
        #Creating project
        create_project(args.project_id, args.project_name)
    elif (args.action).lower() == 'delete':
        #Deleting project
        delete_project(args.project_id)
    else:
        logging.info("Unknown action")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("action", help = "create|delete project")
    parser.add_argument("project_name", help = "Name of the project")
    parser.add_argument("project_id", help = "Customized name chosen for the project, unique across GCP")

    logging.getLogger().setLevel(logging.INFO)
    args = parser.parse_args()
    run(args)
